# Diretta Cielo Kodi plugin

Kodi unofficial plugin to stream HomeAndGarden from the official website.

## Installation

Download the contents of the repository as a zip file and then from the add-ons menu select "Install from zip file"
